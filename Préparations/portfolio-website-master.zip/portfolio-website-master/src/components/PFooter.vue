<template>
  <v-footer app absolute class="font-weight-medium">
    <v-col class="text-center" cols="12">
      {{ new Date().getFullYear() }} —
      <strong>Uzir Thapa</strong>
    </v-col>
  </v-footer>
</template>

<script>
export default {};
</script>

<style>
</style>